export interface userinterface{
email:string;
username:string
}